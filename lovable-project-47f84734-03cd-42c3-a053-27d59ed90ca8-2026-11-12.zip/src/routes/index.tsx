import { createFileRoute, Link } from "@tanstack/react-router";
import { AnimatedLabBackground } from "@/components/game/AnimatedLabBackground";
import { ProfessorProton, type Mood } from "@/components/game/ProfessorProton";
import { Confetti, CartoonFailureSequence } from "@/components/game/Effects";
import { RewardLayer, XPProgressBar } from "@/components/game/Rewards";
import { SettingsPanel, useApplyMotion } from "@/components/game/SettingsPanel";
import { record } from "@/lib/store";
import { play } from "@/lib/sfx";
import { lazy, Suspense, useEffect, useState } from "react";
const Molecule3D = lazy(() => import("@/components/Molecule3D"));
import { AskTutor } from "@/components/AskTutor";
import { fuseSeconds, makePuzzle, SLOTS, type Puzzle } from "@/lib/stereo";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Drug House Explodes — Stereochemistry Bomb Defusal" },
      { name: "description", content: "Rank groups by CIP rules and call R or S before the cartoon lab blows up." },
      { property: "og:title", content: "Drug House Explodes" },
      { property: "og:description", content: "Defuse cartoon lab bombs by solving R/S stereochemistry puzzles." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Game,
});

type Phase = "menu" | "rank" | "call" | "win" | "boom" | "over";

function Molecule({ p, picked, onPick, disabled }: { p: Puzzle; picked: number[]; onPick: (i: number) => void; disabled: boolean }) {
  const R = 95;
  return (
    <svg viewBox="-160 -150 320 290" className="w-full max-w-sm" role="group" aria-label="Molecule with four groups on a stereocentre">
      {SLOTS.map((s, i) => {
        const x = s.draw[0] * R, y = s.draw[1] * R;
        const nx = -y / R * 9, ny = x / R * 9;
        if (s.bond === "wedge") return <polygon key={i} points={`0,0 ${x * 0.72 + nx},${y * 0.72 + ny} ${x * 0.72 - nx},${y * 0.72 - ny}`} className="fill-foreground" />;
        if (s.bond === "dash") return <line key={i} x1={0} y1={0} x2={x * 0.72} y2={y * 0.72} strokeWidth={14} strokeDasharray="3 5" className="stroke-foreground" />;
        return <line key={i} x1={0} y1={0} x2={x * 0.72} y2={y * 0.72} strokeWidth={4} className="stroke-foreground" />;
      })}
      <circle r={16} className="fill-primary" /><text textAnchor="middle" dy={6} className="fill-primary-foreground font-bold">C*</text>
      {SLOTS.map((s, i) => {
        const x = s.draw[0] * R, y = s.draw[1] * R, n = picked.indexOf(i);
        const g = p.groups[i]!;
        return (
          <g key={i} transform={`translate(${x},${y})`} role="button" tabIndex={disabled ? -1 : 0}
            aria-label={`${g.label}${n >= 0 ? `, ranked ${n + 1}` : ""}${s.bond === "wedge" ? ", toward you" : s.bond === "dash" ? ", away from you" : ""}`}
            onClick={() => !disabled && onPick(i)} onKeyDown={(e) => (e.key === "Enter" || e.key === " ") && !disabled && onPick(i)}
            className={disabled ? "" : "cursor-pointer"}>
            <rect x={-38} y={-20} width={76} height={40} rx={10} className={n >= 0 ? "fill-primary" : "fill-card stroke-border"} strokeWidth={2} />
            <text textAnchor="middle" dy={6} className={`text-lg font-bold ${n >= 0 ? "fill-primary-foreground" : "fill-foreground"}`}>{g.label}</text>
            {n >= 0 && <g transform="translate(34,-20)"><circle r={12} className="fill-accent" /><text textAnchor="middle" dy={5} className="fill-accent-foreground text-sm font-bold">{n + 1}</text></g>}
          </g>
        );
      })}
    </svg>
  );
}

function Game() {
  const [phase, setPhase] = useState<Phase>("menu");
  const [level, setLevel] = useState(1);
  const [score, setScore] = useState(0);
  const [lives, setLives] = useState(3);
  const [puz, setPuz] = useState<Puzzle | null>(null);
  const [picked, setPicked] = useState<number[]>([]);
  const [time, setTime] = useState(0);
  const [msg, setMsg] = useState("");
  const [shake, setShake] = useState(false);
  const [best, setBest] = useState(0);
  const [view3d, setView3d] = useState(false);
  const [mistakes, setMistakes] = useState(0);
  useApplyMotion();

  useEffect(() => { setBest(Number(localStorage.getItem("dhe-best") || 0)); }, []);

  const start = (lv: number) => {
    setLevel(lv); setPuz(makePuzzle(lv)); setPicked([]); setMistakes(0); setTime(fuseSeconds(lv)); setMsg(""); setPhase("rank");
  };
  const newGame = () => { setScore(0); setLives(3); start(1); };

  const explode = (why: string) => {
    setMsg(why); setPhase("boom"); play("boom");
    setLives((l) => { const n = l - 1; if (n <= 0) setTimeout(() => setPhase("over"), 1100); return n; });
  };

  useEffect(() => {
    if (phase !== "rank" && phase !== "call") return;
    if (time <= 0) { explode("The fuse ran out!"); return; }
    const t = setTimeout(() => setTime((x) => x - 1), 1000);
    return () => clearTimeout(t);
  }, [phase, time]);

  useEffect(() => {
    if (phase === "over" && score > best) { if (best > 0) record({ type: "newBest" }); setBest(score); localStorage.setItem("dhe-best", String(score)); }
  }, [phase]);

  const pick = (i: number) => {
    if (!puz || phase !== "rank" || picked.includes(i)) return;
    const next = picked.length + 1;
    if (puz.priorities[i] !== next) {
      const g = puz.groups[i]!;
      setMsg(`Not priority ${next}. ${g.label}: ${g.why}. −3 s`);
      setTime((t) => t - 3); setMistakes((m) => m + 1); play("wrong"); setShake(true); setTimeout(() => setShake(false), 900);
      return;
    }
    const np = [...picked, i];
    if (np.length === 3) np.push(puz.priorities.indexOf(4));
    setPicked(np); setMsg(""); play("correct");
    if (np.length === 4) setPhase("call");
  };

  const call = (c: "R" | "S") => {
    if (!puz) return;
    if (c === puz.answer) { setScore((s) => s + 100 * level + time * 10); setPhase("win"); play("win"); record({ type: "defuse", level, mistakes }); }
    else explode(`It was ${puz.answer}. ${puz.answer === "R" ? "Clockwise" : "Counter‑clockwise"} once priority 4 points away.`);
  };

  const fuse = puz ? time / fuseSeconds(level) : 1;
  const lowSlot = puz ? SLOTS[puz.priorities.indexOf(4)]!.bond : "dash";
  const danger = phase === "boom" || ((phase === "rank" || phase === "call") && fuse < 0.3);
  const mood: Mood = phase === "win" ? "happy" : phase === "boom" ? "shocked" : msg ? "think" : "talk";
  const line = phase === "win" ? (mistakes === 0 ? "Flawless! Lowest priority pointed away, and you traced it perfectly." : "Defused! The configuration is locked in.")
    : phase === "boom" ? "Yikes! Smoke everywhere — but every mistake teaches us something."
    : phase === "call" ? (lowSlot === "dash" ? "Priority 4 points away. Trace 1 → 2 → 3!" : "Careful: priority 4 is toward you, so reverse your answer!")
    : msg ? "Compare atomic numbers at the first point of difference." : "Highest atomic number wins top priority!";

  if (phase === "menu" || phase === "over") return (
    <main className="min-h-screen flex flex-col">
      <AnimatedLabBackground />
      <RewardLayer />
      <div className="hazard-stripe h-4" />
      <div className="flex justify-end gap-2 px-4 pt-2"><Link to="/arcade" className="btn-icon" aria-label="Chemistry arcade">🕹️</Link><SettingsPanel /></div>
      <section className="flex-1 flex flex-col items-center justify-center px-6 pb-20 text-center gap-6">
        <ProfessorProton mood={phase === "over" ? "shocked" : "idle"} line={phase === "over" ? "Well… that was dramatic. Let's rebuild!" : "Welcome to my lab! Please don't touch the bombs. Unless you know CIP rules."} />
        <h1 className="font-display text-5xl md:text-7xl text-primary leading-none" style={{ textShadow: "var(--glow)" }}>DRUG HOUSE<br /><span className="text-accent">EXPLODES</span></h1>
        {phase === "over" ? (
          <p className="text-xl">The lab went up. Final score <b className="text-primary">{score}</b> · Best {Math.max(best, score)}</p>
        ) : (
          <p className="max-w-md text-muted-foreground">A rogue cartoon lab is wired with molecular bombs. Each detonator only disarms when you name the correct stereocentre configuration. Rank the groups, call R or S, beat the fuse.</p>
        )}
        <button onClick={newGame} className="font-display text-xl bg-primary text-primary-foreground px-8 py-4 rounded-lg glow hover:scale-105 transition">{phase === "over" ? "Try again" : "Start defusing"}</button>
        <XPProgressBar />
        <Link to="/arcade" className="btn-game bg-secondary text-secondary-foreground">🕹️ Chemistry Arcade</Link>
        <ol className="text-left text-sm text-muted-foreground max-w-sm space-y-1 bg-card p-4 rounded-lg border">
          <li><b className="text-foreground">1.</b> Tap groups in CIP priority order (highest atomic number first; ties: compare the next atoms).</li>
          <li><b className="text-foreground">2.</b> Point priority 4 away from you.</li>
          <li><b className="text-foreground">3.</b> Trace 1 → 2 → 3: clockwise = R, counter‑clockwise = S.</li>
          <li><b className="text-foreground">4.</b> If priority 4 points toward you (wedge), reverse it.</li>
        </ol>
        <p className="text-xs text-muted-foreground">Fictional cartoon game. Chemistry puzzles only.</p>
      </section>
    </main>
  );

  return (
    <main className={`min-h-screen flex flex-col ${shake ? "animate-shake" : ""}`}>
      <AnimatedLabBackground danger={danger} success={phase === "win"} />
      <RewardLayer />
      {phase === "win" && <Confetti />}
      <div className="hazard-stripe h-3" />
      <header className="flex justify-between items-center gap-2 px-4 py-3 font-display text-sm">
        <span>LVL {level}</span><span className="text-primary">{score}</span>
        <span aria-label={`${lives} lives`}>{"💣".repeat(Math.max(lives, 0))}</span>
        <SettingsPanel />
      </header>
      <div className="mx-4 h-4 rounded-full bg-muted overflow-hidden" role="progressbar" aria-valuenow={time} aria-valuemin={0} aria-valuemax={fuseSeconds(level)} aria-label="Fuse">
        <div className={`h-full transition-all duration-1000 ${fuse < 0.3 ? "bg-destructive" : "bg-accent"}`} style={{ width: `${Math.max(0, fuse) * 100}%` }} />
      </div>
      <p className="text-center text-xs text-muted-foreground mt-1">{time}s on the fuse</p>

      <section className="flex-1 flex flex-col items-center px-4 pb-20 gap-3 relative">
        <div className="mt-2"><ProfessorProton mood={mood} line={line} size={56} /></div>
        <p className="mt-3 text-center font-semibold" aria-live="polite">
          {phase === "rank" && `Tap priority ${picked.length + 1}`}
          {phase === "call" && "Priority 4 auto-placed. Is this R or S?"}
          {phase === "win" && "✅ Defused!"}
          {phase === "boom" && "💥 KABOOM!"}
        </p>
        <button onClick={() => setView3d((v) => !v)} className="text-xs underline text-accent">{view3d ? "Back to 2D drawing" : "View in 3D"}</button>
        {puz && (view3d
          ? <Suspense fallback={<p className="text-sm text-muted-foreground">Loading 3D…</p>}><Molecule3D p={puz} showRanks={phase !== "rank"} /></Suspense>
          : <Molecule p={puz} picked={picked} onPick={pick} disabled={phase !== "rank"} />)}
        <p className="text-xs text-muted-foreground">Wedge = toward you · Dashes = away from you</p>
        {msg && <p className="text-sm text-center bg-card border rounded-md px-3 py-2 max-w-sm animate-pop" role="status">{msg}</p>}

        {phase === "call" && (
          <div className="flex gap-4 animate-pop">
            {(["R", "S"] as const).map((c) => (
              <button key={c} onClick={() => call(c)} className="font-display text-4xl w-28 h-24 rounded-xl bg-primary text-primary-foreground glow hover:scale-105 transition">{c}</button>
            ))}
          </div>
        )}
        {phase === "call" && lowSlot !== "dash" && <p className="text-xs text-accent">Hint: priority 4 isn't on the dash — think carefully.</p>}

        {phase === "win" && <button onClick={() => start(level + 1)} className="font-display bg-accent text-accent-foreground px-6 py-3 rounded-lg animate-pop">Next bomb →</button>}
        {phase === "boom" && (
          <>
                        <CartoonFailureSequence />
            {lives > 0 && <button onClick={() => start(level)} className="font-display bg-destructive text-destructive-foreground px-6 py-3 rounded-lg relative">Rebuild &amp; retry</button>}
          </>
        )}
        <AskTutor puzzle={puz} />
      </section>
    </main>
  );
}
