import { createFileRoute, Link } from "@tanstack/react-router";
import { ChemistryArcade } from "@/components/game/ChemistryArcade";
import { AnimatedLabBackground } from "@/components/game/AnimatedLabBackground";
import { RewardCollection, RewardLayer, XPProgressBar } from "@/components/game/Rewards";
import { SettingsPanel, useApplyMotion } from "@/components/game/SettingsPanel";
import { progress } from "@/lib/store";

export const Route = createFileRoute("/arcade")({
  head: () => ({
    meta: [
      { title: "Chemistry Arcade — Drug House Explodes" },
      { name: "description", content: "Quick chemistry mini-games: Periodic Table Sprint and Molecular Shape Match. Earn XP and unlock achievements." },
      { property: "og:title", content: "Chemistry Arcade — Drug House Explodes" },
      { property: "og:description", content: "Replayable chemistry mini-games with XP, ranks and achievements." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Arcade,
});

function Arcade() {
  useApplyMotion();
  const p = progress.use();
  return (
    <main className="min-h-screen flex flex-col">
      <AnimatedLabBackground />
      <RewardLayer />
      <div className="hazard-stripe h-3" />
      <header className="flex items-center justify-between px-4 py-2">
        <Link to="/" className="btn-icon" aria-label="Back to bomb defusal">💣</Link>
        <h1 className="font-display text-lg text-primary">CHEM ARCADE</h1>
        <SettingsPanel />
      </header>
      <section className="flex-1 flex flex-col items-center gap-6 px-4 pb-24">
        <XPProgressBar />
        <div className="flex gap-3 text-xs text-muted-foreground"><span>🔥 {p.streak}-day streak</span><span>💣 {p.defused} defused</span><span>🧪 {p.elements} elements</span><span>🔺 {p.shapes} shapes</span></div>
        <ChemistryArcade />
        <h2 className="font-display text-primary mt-4">Achievement shelf</h2>
        <div className="w-full max-w-md"><RewardCollection /></div>
      </section>
    </main>
  );
}
