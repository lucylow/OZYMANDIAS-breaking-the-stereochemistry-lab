// Periodic table data and ground-state electron configurations. Pure TS.
const RAW = "H Hydrogen,He Helium,Li Lithium,Be Beryllium,B Boron,C Carbon,N Nitrogen,O Oxygen,F Fluorine,Ne Neon,Na Sodium,Mg Magnesium,Al Aluminium,Si Silicon,P Phosphorus,S Sulfur,Cl Chlorine,Ar Argon,K Potassium,Ca Calcium,Sc Scandium,Ti Titanium,V Vanadium,Cr Chromium,Mn Manganese,Fe Iron,Co Cobalt,Ni Nickel,Cu Copper,Zn Zinc,Ga Gallium,Ge Germanium,As Arsenic,Se Selenium,Br Bromine,Kr Krypton,Rb Rubidium,Sr Strontium,Y Yttrium,Zr Zirconium,Nb Niobium,Mo Molybdenum,Tc Technetium,Ru Ruthenium,Rh Rhodium,Pd Palladium,Ag Silver,Cd Cadmium,In Indium,Sn Tin,Sb Antimony,Te Tellurium,I Iodine,Xe Xenon,Cs Caesium,Ba Barium,La Lanthanum,Ce Cerium,Pr Praseodymium,Nd Neodymium,Pm Promethium,Sm Samarium,Eu Europium,Gd Gadolinium,Tb Terbium,Dy Dysprosium,Ho Holmium,Er Erbium,Tm Thulium,Yb Ytterbium,Lu Lutetium,Hf Hafnium,Ta Tantalum,W Tungsten,Re Rhenium,Os Osmium,Ir Iridium,Pt Platinum,Au Gold,Hg Mercury,Tl Thallium,Pb Lead,Bi Bismuth,Po Polonium,At Astatine,Rn Radon,Fr Francium,Ra Radium,Ac Actinium,Th Thorium,Pa Protactinium,U Uranium,Np Neptunium,Pu Plutonium,Am Americium,Cm Curium,Bk Berkelium,Cf Californium,Es Einsteinium,Fm Fermium,Md Mendelevium,No Nobelium,Lr Lawrencium,Rf Rutherfordium,Db Dubnium,Sg Seaborgium,Bh Bohrium,Hs Hassium,Mt Meitnerium,Ds Darmstadtium,Rg Roentgenium,Cn Copernicium,Nh Nihonium,Fl Flerovium,Mc Moscovium,Lv Livermorium,Ts Tennessine,Og Oganesson";

export type Category = "alkali" | "alkaline" | "transition" | "post" | "metalloid" | "nonmetal" | "halogen" | "noble" | "lanthanide" | "actinide";
export type Element = { z: number; symbol: string; name: string; row: number; col: number; category: Category; en?: number | undefined };

// Pauling electronegativity for elements used in CIP puzzles.
const EN: Record<number, number> = { 1: 2.2, 5: 2.04, 6: 2.55, 7: 3.04, 8: 3.44, 9: 3.98, 14: 1.9, 15: 2.19, 16: 2.58, 17: 3.16, 35: 2.96, 53: 2.66 };

function position(z: number): [number, number] {
  if (z === 1) return [1, 1];
  if (z === 2) return [1, 18];
  const p = [[3, 10, 2], [11, 18, 3]] as const;
  for (const [a, b, r] of p) if (z >= a && z <= b) return [r, z - a < 2 ? z - a + 1 : z - a + 11];
  if (z <= 36) return [4, z - 18];
  if (z <= 54) return [5, z - 36];
  if (z <= 56) return [6, z - 54];
  if (z <= 71) return [9, z - 57 + 3];
  if (z <= 86) return [6, z - 68];
  if (z <= 88) return [7, z - 86];
  if (z <= 103) return [10, z - 89 + 3];
  return [7, z - 100];
}

function category(z: number, col: number, row: number): Category {
  if (row === 9) return "lanthanide";
  if (row === 10) return "actinide";
  if ([2, 10, 18, 36, 54, 86, 118].includes(z)) return "noble";
  if ([9, 17, 35, 53, 85, 117].includes(z)) return "halogen";
  if ([1, 6, 7, 8, 15, 16, 34].includes(z)) return "nonmetal";
  if ([5, 14, 32, 33, 51, 52].includes(z)) return "metalloid";
  if (col === 1) return "alkali";
  if (col === 2) return "alkaline";
  if (col >= 3 && col <= 12) return "transition";
  return "post";
}

export const ELEMENTS: Element[] = RAW.split(",").map((s, i) => {
  const [symbol, name] = s.split(" ") as [string, string];
  const z = i + 1;
  const [row, col] = position(z);
  return { z, symbol, name, row, col, category: category(z, col, row), en: EN[z] };
});
export const bySymbol = (s: string) => ELEMENTS.find((e) => e.symbol === s)!;

// Madelung (n + l) filling order.
const ORDER = ["1s", "2s", "2p", "3s", "3p", "4s", "3d", "4p", "5s", "4d", "5p", "6s", "4f", "5d", "6p", "7s", "5f", "6d", "7p"];
const CAP: Record<string, number> = { s: 2, p: 6, d: 10, f: 14 };
// Known ground-state exceptions: [from, to, electrons moved].
const EXC: Record<number, [string, string, number]> = {
  24: ["4s", "3d", 1], 29: ["4s", "3d", 1], 41: ["5s", "4d", 1], 42: ["5s", "4d", 1], 44: ["5s", "4d", 1], 45: ["5s", "4d", 1],
  46: ["5s", "4d", 2], 47: ["5s", "4d", 1], 78: ["6s", "5d", 1], 79: ["6s", "5d", 1],
  57: ["4f", "5d", 1], 58: ["4f", "5d", 1], 64: ["4f", "5d", 1],
  89: ["5f", "6d", 1], 90: ["5f", "6d", 2], 91: ["5f", "6d", 1], 92: ["5f", "6d", 1], 93: ["5f", "6d", 1], 96: ["5f", "6d", 1],
};

export function subshells(z: number): [string, number][] {
  let left = z;
  const out: [string, number][] = [];
  for (const o of ORDER) {
    if (left <= 0) break;
    const n = Math.min(CAP[o[1]!]!, left);
    out.push([o, n]);
    left -= n;
  }
  const e = EXC[z];
  if (e) {
    const from = out.find((x) => x[0] === e[0]);
    if (from) from[1] -= e[2];
    const to = out.find((x) => x[0] === e[1]);
    if (to) to[1] += e[2];
    else out.push([e[1], e[2]]);
  }
  return out.filter((x) => x[1] > 0).sort((a, b) => Number(a[0][0]) - Number(b[0][0]) || "spdf".indexOf(a[0][1]!) - "spdf".indexOf(b[0][1]!));
}

const SUP = "⁰¹²³⁴⁵⁶⁷⁸⁹";
export const configString = (z: number) =>
  subshells(z).map(([o, n]) => o + String(n).split("").map((d) => SUP[+d]).join("")).join(" ");

export function shells(z: number): number[] {
  const s: number[] = [];
  for (const [o, n] of subshells(z)) s[Number(o[0]) - 1] = (s[Number(o[0]) - 1] ?? 0) + n;
  return Array.from(s, (x) => x ?? 0);
}

// CPK-style colours (Jmol) used for atom illustrations — scientific data, not theme.
export const CPK: Record<string, string> = { H: "#f2f2f2", C: "#5a5a5a", N: "#3050f8", O: "#ff2a1a", F: "#90e050", Cl: "#1ff01f", Br: "#a62929", I: "#940094", S: "#ffd52f", B: "#ffb5b5", P: "#ff8000" };
export const cpk = (s: string) => CPK[s] ?? "#c88dff";
