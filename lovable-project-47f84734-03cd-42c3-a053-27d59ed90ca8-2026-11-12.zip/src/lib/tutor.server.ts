import { createOpenAI } from "@ai-sdk/openai";
import { streamText } from "ai";

const INSTRUCTIONS = `You are a friendly organic chemistry tutor inside an educational stereochemistry puzzle game.
Explain R/S (CIP) assignments step by step: rank the four groups by atomic number (first point of difference for ties),
orient priority 4 away from the viewer, trace 1→2→3, clockwise = R, counter-clockwise = S, and reverse if priority 4 points toward the viewer.
Use the molecule data provided as ground truth: each group's on-screen clock position and bond type are given, so describe the actual 1→2→3 path using those positions (e.g. "from 10 o'clock to 4 o'clock"). Never say positions are unknown. Keep answers under 200 words, plain text, no markdown headings.
Only discuss chemistry education; never give synthesis instructions for drugs, controlled substances, or explosives.`;

export type MoleculeContext = { groups: { label: string; bond: string; position: string; priority: number }[]; answer: "R" | "S" } | null;

export async function explainStereo(question: string, molecule: MoleculeContext): Promise<string> {
  const apiKey = process.env["LOVABLE_API_KEY"];
  if (!apiKey) throw new Error("AI is not configured.");
  let runId: string | undefined;
  const provider = createOpenAI({
    baseURL: "https://ai.gateway.lovable.dev/v1",
    apiKey,
    headers: { "Lovable-API-Key": apiKey, "X-Lovable-AIG-SDK": "vercel-ai-sdk" },
    fetch: async (input, init) => {
      const headers = new Headers(init?.headers);
      if (runId) headers.set("X-Lovable-AIG-Run-ID", runId);
      const res = await fetch(input, { ...init, headers });
      runId ??= res.headers.get("X-Lovable-AIG-Run-ID")?.trim() || undefined;
      return res;
    },
  });
  const context = molecule
    ? `Current molecule (bond: plain = in page plane, wedge = toward viewer, dash = away):\n${molecule.groups
        .map((g) => `- ${g.label} at ${g.position} on screen, ${g.bond} bond, CIP priority ${g.priority}`)
        .join("\n")}\nCorrect configuration: ${molecule.answer}`
    : "No molecule is on screen.";
  const result = streamText({
    model: provider.responses("openai/gpt-6-astra"),
    instructions: INSTRUCTIONS,
    messages: [{ role: "user", content: `${context}\n\nPlayer question: ${question}` }],
    maxRetries: 0,
    providerOptions: {
      openai: { store: false, forceReasoning: true, reasoningEffort: "low", reasoningSummary: "auto", include: ["reasoning.encrypted_content"] },
    },
  });
  const text = await result.text;
  if (!text.trim()) throw new Error("The tutor couldn't answer that one.");
  return text;
}
