import { describe, expect, it } from "vitest";
import { apply, EMPTY, rankProgress, xpFor } from "./progress";

describe("progress rules", () => {
  it("defuse XP rewards level and a clean solve", () => {
    expect(xpFor({ type: "defuse", level: 1, mistakes: 0 })).toBe(45);
    expect(xpFor({ type: "defuse", level: 3, mistakes: 2 })).toBe(50);
  });
  it("ranks start at Lab Intern and level up at 100 XP", () => {
    expect(rankProgress(0).title).toBe("Lab Intern");
    expect(rankProgress(100).title).toBe("Atom Apprentice");
    expect(rankProgress(5000).title).toBe("Master Chemist");
  });
  it("unlocks first defuse and perfect lab once", () => {
    const a = apply(EMPTY, { type: "defuse", level: 1, mistakes: 0 }, "2026-01-01");
    expect(a.unlocked).toEqual(["first-defuse", "perfect-lab"]);
    const b = apply(a.progress, { type: "defuse", level: 1, mistakes: 0 }, "2026-01-01");
    expect(b.unlocked).toEqual([]);
  });
  it("Periodic Explorer needs 20 elements", () => {
    let p = EMPTY;
    for (let i = 0; i < 19; i++) p = apply(p, { type: "element" }, "2026-01-01").progress;
    expect(apply(p, { type: "element" }, "2026-01-01").unlocked).toContain("periodic-explorer");
  });
  it("streak grows on consecutive days and resets after a gap", () => {
    let p = apply(EMPTY, { type: "element" }, "2026-01-01").progress;
    p = apply(p, { type: "element" }, "2026-01-02").progress;
    expect(p.streak).toBe(2);
    expect(apply(p, { type: "element" }, "2026-01-05").progress.streak).toBe(1);
  });
});
