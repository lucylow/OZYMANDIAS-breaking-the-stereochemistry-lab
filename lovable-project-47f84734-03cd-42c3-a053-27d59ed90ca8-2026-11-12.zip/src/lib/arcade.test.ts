import { describe, expect, it } from "vitest";
import { elementQuestion, shapeQuestion } from "./arcade";
import { ELEMENTS } from "./elements";

describe("arcade questions", () => {
  it("element questions have exactly one correct, unique option", () => {
    for (let i = 0; i < 200; i++) {
      const q = elementQuestion();
      expect(new Set(q.options).size).toBe(4);
      expect(q.options.filter((o) => o === q.answer)).toHaveLength(1);
    }
  });
  it("atomic-number answers match the periodic table", () => {
    for (let i = 0; i < 200; i++) {
      const q = elementQuestion();
      const m = q.prompt.match(/Atomic number (\d+)/);
      if (m) expect(ELEMENTS[Number(m[1]) - 1]!.symbol).toBe(q.answer);
    }
  });
  it("water is bent, methane tetrahedral", () => {
    for (let i = 0; i < 100; i++) {
      const q = shapeQuestion();
      if (q.model.id === "h2o") expect(q.answer).toBe("Bent");
      if (q.model.id === "ch4") expect(q.answer).toBe("Tetrahedral");
      expect(q.options).toContain(q.answer);
    }
  });
});
