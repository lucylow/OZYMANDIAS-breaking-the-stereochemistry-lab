// Synthesized, optional sound effects (Web Audio). Respects mute + volume.
import { settings } from "./store";
let ctx: AudioContext | null = null;
type Note = [freq: number, at: number, dur: number, type?: OscillatorType];
const SOUNDS: Record<string, Note[]> = {
  click: [[660, 0, 0.05, "square"]],
  bubble: [[400, 0, 0.08, "sine"], [620, 0.07, 0.08, "sine"], [880, 0.14, 0.1, "sine"]],
  correct: [[523, 0, 0.1, "triangle"], [784, 0.09, 0.16, "triangle"]],
  wrong: [[220, 0, 0.18, "sawtooth"], [180, 0.12, 0.2, "sawtooth"]],
  win: [[523, 0, 0.1, "triangle"], [659, 0.1, 0.1, "triangle"], [784, 0.2, 0.1, "triangle"], [1047, 0.3, 0.25, "triangle"]],
  boom: [[90, 0, 0.5, "sawtooth"], [60, 0.1, 0.6, "square"]],
  levelup: [[392, 0, 0.12, "square"], [523, 0.12, 0.12, "square"], [659, 0.24, 0.12, "square"], [784, 0.36, 0.3, "square"]],
  alarm: [[880, 0, 0.15, "square"], [660, 0.18, 0.15, "square"], [880, 0.36, 0.15, "square"]],
};
export function play(name: keyof typeof SOUNDS) {
  const s = settings.get();
  if (s.muted || s.volume <= 0 || typeof window === "undefined") return;
  try {
    ctx ??= new AudioContext();
    const t0 = ctx.currentTime;
    for (const [f, at, dur, type = "sine"] of SOUNDS[name]!) {
      const o = ctx.createOscillator(), g = ctx.createGain();
      o.type = type; o.frequency.value = f;
      g.gain.setValueAtTime(0.0001, t0 + at);
      g.gain.exponentialRampToValueAtTime(0.15 * s.volume, t0 + at + 0.01);
      g.gain.exponentialRampToValueAtTime(0.0001, t0 + at + dur);
      o.connect(g).connect(ctx.destination); o.start(t0 + at); o.stop(t0 + at + dur + 0.02);
    }
  } catch { /* audio unavailable */ }
}
