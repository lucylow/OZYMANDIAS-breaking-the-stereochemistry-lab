// Pure XP, rank and achievement rules. No React.
export const RANKS = ["Lab Intern", "Atom Apprentice", "Bond Builder", "Molecule Explorer", "Chemistry Detective", "Reaction Specialist", "Geometry Master", "Organic Chemistry Expert", "Stereochemistry Specialist", "Master Chemist"] as const;
export const THRESHOLDS = [0, 100, 250, 450, 700, 1000, 1350, 1750, 2200, 2700];

export const ACHIEVEMENTS = {
  "first-defuse": { name: "First Fuse", desc: "Defuse your first stereocentre bomb.", icon: "🧯" },
  "perfect-lab": { name: "Perfect Lab", desc: "Defuse a bomb with zero mistakes.", icon: "✨" },
  "chirality-champion": { name: "Chirality Champion", desc: "Solve 10 R/S puzzles.", icon: "🏆" },
  "periodic-explorer": { name: "Periodic Explorer", desc: "Identify 20 elements in Periodic Sprint.", icon: "🧪" },
  "shape-shifter": { name: "Shape Shifter", desc: "Match 10 molecular geometries.", icon: "🔺" },
  "comeback-chemist": { name: "Comeback Chemist", desc: "Beat your previous best score.", icon: "📈" },
} as const;
export type AchievementId = keyof typeof ACHIEVEMENTS;

export type Progress = { xp: number; defused: number; elements: number; shapes: number; achievements: AchievementId[]; streak: number; lastDay: string };
export const EMPTY: Progress = { xp: 0, defused: 0, elements: 0, shapes: 0, achievements: [], streak: 0, lastDay: "" };

export type GameEvent =
  | { type: "defuse"; level: number; mistakes: number }
  | { type: "element" }
  | { type: "shape" }
  | { type: "newBest" };

export const rankIndex = (xp: number) => { let i = 0; THRESHOLDS.forEach((t, k) => { if (xp >= t) i = k; }); return i; };
export function rankProgress(xp: number) {
  const i = rankIndex(xp), lo = THRESHOLDS[i]!, hi = THRESHOLDS[i + 1];
  return { index: i, title: RANKS[i]!, into: xp - lo, span: hi === undefined ? 0 : hi - lo, pct: hi === undefined ? 1 : (xp - lo) / (hi - lo) };
}

// Only correct answers earn XP; clean solves earn a bonus so understanding beats guessing.
export function xpFor(e: GameEvent): number {
  switch (e.type) {
    case "defuse": return 20 + 10 * e.level + (e.mistakes === 0 ? 15 : 0);
    case "element": return 5;
    case "shape": return 8;
    case "newBest": return 0;
  }
}

const dayDiff = (a: string, b: string) => Math.round((Date.parse(b) - Date.parse(a)) / 86400000);

export function apply(p: Progress, e: GameEvent, today = new Date().toISOString().slice(0, 10)) {
  const n: Progress = { ...p, achievements: [...p.achievements] };
  const gained = xpFor(e);
  n.xp += gained;
  if (e.type === "defuse") n.defused++;
  if (e.type === "element") n.elements++;
  if (e.type === "shape") n.shapes++;
  if (gained > 0 && n.lastDay !== today) { n.streak = n.lastDay && dayDiff(n.lastDay, today) === 1 ? n.streak + 1 : 1; n.lastDay = today; }
  const unlock: AchievementId[] = [];
  const add = (id: AchievementId, ok: boolean) => { if (ok && !n.achievements.includes(id)) { n.achievements.push(id); unlock.push(id); } };
  add("first-defuse", n.defused >= 1);
  add("perfect-lab", e.type === "defuse" && e.mistakes === 0);
  add("chirality-champion", n.defused >= 10);
  add("periodic-explorer", n.elements >= 20);
  add("shape-shifter", n.shapes >= 10);
  add("comeback-chemist", e.type === "newBest");
  return { progress: n, gained, leveledUp: rankIndex(n.xp) > rankIndex(p.xp), unlocked: unlock };
}
