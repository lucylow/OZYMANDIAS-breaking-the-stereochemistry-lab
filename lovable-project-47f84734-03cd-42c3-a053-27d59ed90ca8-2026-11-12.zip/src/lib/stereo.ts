import { TETRA } from "./geometry";
// Stereochemistry engine: CIP priorities + R/S from 3D geometry.
export type Group = { label: string; rank: number; why: string; atom: string; z: number; set?: string };

// Lower rank = higher CIP priority. Ordered by first-point-of-difference.
export const GROUPS: Group[] = [
  { label: "I", rank: 1, why: "Iodine, Z = 53", atom: "I", z: 53 },
  { label: "Br", rank: 2, why: "Bromine, Z = 35", atom: "Br", z: 35 },
  { label: "Cl", rank: 3, why: "Chlorine, Z = 17", atom: "Cl", z: 17 },
  { label: "SH", rank: 4, why: "Sulfur, Z = 16", atom: "S", z: 16, set: "H" },
  { label: "F", rank: 5, why: "Fluorine, Z = 9", atom: "F", z: 9 },
  { label: "OH", rank: 6, why: "Oxygen, Z = 8", atom: "O", z: 8, set: "H" },
  { label: "NH₂", rank: 7, why: "Nitrogen, Z = 7", atom: "N", z: 7, set: "H,H" },
  { label: "COOH", rank: 8, why: "Carbon with (O,O,O)", atom: "C", z: 6, set: "O,O,O" },
  { label: "CHO", rank: 9, why: "Carbon with (O,O,H)", atom: "C", z: 6, set: "O,O,H" },
  { label: "CH₂OH", rank: 10, why: "Carbon with (O,H,H)", atom: "C", z: 6, set: "O,H,H" },
  { label: "CH=CH₂", rank: 11, why: "Carbon with (C,C,H)", atom: "C", z: 6, set: "C,C,H" },
  { label: "CH₂CH₃", rank: 12, why: "Carbon with (C,H,H)", atom: "C", z: 6, set: "C,H,H" },
  { label: "CH₃", rank: 13, why: "Carbon with (H,H,H)", atom: "C", z: 6, set: "H,H,H" },
  { label: "H", rank: 14, why: "Hydrogen, Z = 1", atom: "H", z: 1 },
];

export type V3 = [number, number, number];
export type Bond = "plain" | "wedge" | "dash";
// Four bond slots around the stereocentre. x right, y UP, z toward viewer.
// `v` is the ideal tetrahedral direction (109.5°); `draw` is the conventional
// 2D wedge-dash projection (SVG, y down). Both encode the same handedness (tested).
export const SLOTS: { v: V3; bond: Bond; draw: [number, number] }[] = [
  { v: TETRA[0]!, bond: "plain", draw: [-0.58, -0.82] },
  { v: TETRA[1]!, bond: "plain", draw: [-0.58, 0.82] },
  { v: TETRA[2]!, bond: "wedge", draw: [0.8, 0.5] },
  { v: TETRA[3]!, bond: "dash", draw: [0.8, -0.5] },
];
/** What a reader infers from the 2D drawing (plain = in plane, wedge = toward, dash = away). */
export const READ_FROM_DRAWING: V3[] = SLOTS.map((s) => [s.draw[0], -s.draw[1], s.bond === "wedge" ? 0.6 : s.bond === "dash" ? -0.6 : 0]);

/** priorities[i] = 1..4 for the group in slot i. */
export function configuration(vectors: V3[], priorities: number[]): "R" | "S" {
  const at = (p: number) => vectors[priorities.indexOf(p)]!;
  const v4 = at(4);
  const [a, b, c] = [1, 2, 3].map((p) => {
    const v = at(p);
    return [v[0] - v4[0], v[1] - v4[1], v[2] - v4[2]] as V3;
  }) as [V3, V3, V3];
  const det =
    a[0] * (b[1] * c[2] - b[2] * c[1]) -
    a[1] * (b[0] * c[2] - b[2] * c[0]) +
    a[2] * (b[0] * c[1] - b[1] * c[0]);
  return det < 0 ? "R" : "S";
}

export type Puzzle = { groups: Group[]; priorities: number[]; answer: "R" | "S" };

export function makePuzzle(level: number, rnd = Math.random): Puzzle {
  const pool = [...GROUPS];
  const picked: Group[] = [];
  // Early levels always include H for an easy lowest priority.
  if (level < 3) picked.push(pool.splice(pool.length - 1, 1)[0]!);
  while (picked.length < 4) picked.push(pool.splice(Math.floor(rnd() * pool.length), 1)[0]!);
  // Shuffle into slots; on levels 1-2 put H on the dash (pointing away).
  const groups = picked.sort(() => rnd() - 0.5);
  if (level < 3) {
    const h = groups.findIndex((g) => g.label === "H");
    [groups[h], groups[3]] = [groups[3]!, groups[h]!];
  }
  const sorted = [...groups].sort((x, y) => x.rank - y.rank);
  const priorities = groups.map((g) => sorted.indexOf(g) + 1);
  return { groups, priorities, answer: configuration(SLOTS.map((s) => s.v), priorities) };
}

export const fuseSeconds = (level: number) => Math.max(12, 40 - level * 3);
