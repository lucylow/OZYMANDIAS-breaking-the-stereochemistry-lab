// Molecular geometry models (VSEPR) with real bond angles and approximate lengths in Å.
export type Atom = { el: string; p: [number, number, number] };
export type Bond = { a: number; b: number; order: 1 | 2 | 3; style?: "wedge" | "dash" };
export type Model = { id: string; name: string; formula: string; shape: string; angle: string; lonePairs: number; atoms: Atom[]; bonds: Bond[]; note: string };

const rad = (d: number) => (d * Math.PI) / 180;
const T = 109.47;
// Ideal tetrahedral unit vectors: two in the xy-plane, two in the xz-plane.
export const TETRA: [number, number, number][] = [
  [-Math.sin(rad(T / 2)) * 0 - Math.cos(rad(T / 2)), Math.sin(rad(T / 2)), 0],
  [-Math.cos(rad(T / 2)), -Math.sin(rad(T / 2)), 0],
  [Math.cos(rad(T / 2)), 0, Math.sin(rad(T / 2))],
  [Math.cos(rad(T / 2)), 0, -Math.sin(rad(T / 2))],
];
const sc = (v: [number, number, number], k: number): [number, number, number] => [v[0] * k, v[1] * k, v[2] * k];
const inPlane = (deg: number, len: number): [number, number, number] => [Math.cos(rad(deg)) * len, Math.sin(rad(deg)) * len, 0];

// Pyramidal / bent: rotate bonds so the H–X–H angle matches experiment.
function pyramid(angle: number, len: number, n: number): [number, number, number][] {
  // bonds evenly around -y axis at polar angle θ with pairwise angle `angle`
  const phi = (2 * Math.PI) / n;
  const c = Math.cos(rad(angle));
  // cos(angle) = cos²θ + sin²θ cos(phi)
  const s2 = (1 - c) / (1 - Math.cos(phi));
  const sinT = Math.sqrt(s2), cosT = Math.sqrt(1 - s2);
  return Array.from({ length: n }, (_, i) => sc([sinT * Math.cos(i * phi), -cosT, sinT * Math.sin(i * phi)], len));
}

export const MODELS: Model[] = [
  { id: "co2", name: "Carbon dioxide", formula: "CO₂", shape: "Linear", angle: "180°", lonePairs: 0, note: "Two C=O double bonds; no lone pairs on carbon.",
    atoms: [{ el: "C", p: [0, 0, 0] }, { el: "O", p: [-1.16, 0, 0] }, { el: "O", p: [1.16, 0, 0] }], bonds: [{ a: 0, b: 1, order: 2 }, { a: 0, b: 2, order: 2 }] },
  { id: "hcn", name: "Hydrogen cyanide", formula: "HCN", shape: "Linear", angle: "180°", lonePairs: 0, note: "One C≡N triple bond (one σ + two π).",
    atoms: [{ el: "C", p: [0, 0, 0] }, { el: "H", p: [-1.07, 0, 0] }, { el: "N", p: [1.16, 0, 0] }], bonds: [{ a: 0, b: 1, order: 1 }, { a: 0, b: 2, order: 3 }] },
  { id: "bf3", name: "Boron trifluoride", formula: "BF₃", shape: "Trigonal planar", angle: "120°", lonePairs: 0, note: "Three bonding domains spread in one plane.",
    atoms: [{ el: "B", p: [0, 0, 0] }, ...[90, 210, 330].map((d) => ({ el: "F", p: inPlane(d, 1.31) }))], bonds: [1, 2, 3].map((b) => ({ a: 0, b, order: 1 as const })) },
  { id: "h2co", name: "Formaldehyde", formula: "H₂CO", shape: "Trigonal planar", angle: "≈ 120° (H–C–H 116.5°)", lonePairs: 0, note: "The C=O double bond squeezes the H–C–H angle slightly.",
    atoms: [{ el: "C", p: [0, 0, 0] }, { el: "O", p: [0, 1.21, 0] }, { el: "H", p: inPlane(-90 - 58.25, 1.11) }, { el: "H", p: inPlane(-90 + 58.25, 1.11) }], bonds: [{ a: 0, b: 1, order: 2 }, { a: 0, b: 2, order: 1 }, { a: 0, b: 3, order: 1 }] },
  { id: "c2h4", name: "Ethene", formula: "C₂H₄", shape: "Trigonal planar at each C", angle: "≈ 121° (H–C–H 117°)", lonePairs: 0, note: "The C=C double bond locks all six atoms in one plane — no free rotation.",
    atoms: [{ el: "C", p: [-0.67, 0, 0] }, { el: "C", p: [0.67, 0, 0] }, ...[[-1, 1], [-1, -1], [1, 1], [1, -1]].map(([sx, sy]) => ({ el: "H", p: [sx! * (0.67 + 1.09 * Math.cos(rad(58.5))), sy! * 1.09 * Math.sin(rad(58.5)), 0] as [number, number, number] }))],
    bonds: [{ a: 0, b: 1, order: 2 }, { a: 0, b: 2, order: 1 }, { a: 0, b: 3, order: 1 }, { a: 1, b: 4, order: 1 }, { a: 1, b: 5, order: 1 }] },
  { id: "c2h2", name: "Ethyne", formula: "C₂H₂", shape: "Linear", angle: "180°", lonePairs: 0, note: "C≡C triple bond, the shortest carbon–carbon bond (1.20 Å).",
    atoms: [{ el: "C", p: [-0.6, 0, 0] }, { el: "C", p: [0.6, 0, 0] }, { el: "H", p: [-1.66, 0, 0] }, { el: "H", p: [1.66, 0, 0] }], bonds: [{ a: 0, b: 1, order: 3 }, { a: 0, b: 2, order: 1 }, { a: 1, b: 3, order: 1 }] },
  { id: "ch4", name: "Methane", formula: "CH₄", shape: "Tetrahedral", angle: "109.5°", lonePairs: 0, note: "Wedge = toward you, hashed wedge = away. Every stereocentre is built on this shape.",
    atoms: [{ el: "C", p: [0, 0, 0] }, ...TETRA.map((v) => ({ el: "H", p: sc(v, 1.09) }))], bonds: [{ a: 0, b: 1, order: 1 }, { a: 0, b: 2, order: 1 }, { a: 0, b: 3, order: 1, style: "wedge" }, { a: 0, b: 4, order: 1, style: "dash" }] },
  { id: "nh3", name: "Ammonia", formula: "NH₃", shape: "Trigonal pyramidal", angle: "107°", lonePairs: 1, note: "One lone pair pushes the N–H bonds closer than 109.5°.",
    atoms: [{ el: "N", p: [0, 0, 0] }, ...pyramid(107, 1.01, 3).map((p) => ({ el: "H", p }))], bonds: [1, 2, 3].map((b) => ({ a: 0, b, order: 1 as const })) },
  { id: "h2o", name: "Water", formula: "H₂O", shape: "Bent", angle: "104.5°", lonePairs: 2, note: "Two lone pairs compress the H–O–H angle further.",
    atoms: [{ el: "O", p: [0, 0, 0] }, { el: "H", p: inPlane(-90 - 52.25, 0.96) }, { el: "H", p: inPlane(-90 + 52.25, 0.96) }], bonds: [{ a: 0, b: 1, order: 1 }, { a: 0, b: 2, order: 1 }] },
];

export function angleDeg(a: [number, number, number], o: [number, number, number], b: [number, number, number]) {
  const u = [a[0] - o[0], a[1] - o[1], a[2] - o[2]], v = [b[0] - o[0], b[1] - o[1], b[2] - o[2]];
  const d = u[0]! * v[0]! + u[1]! * v[1]! + u[2]! * v[2]!;
  return (Math.acos(d / (Math.hypot(...u) * Math.hypot(...v))) * 180) / Math.PI;
}
