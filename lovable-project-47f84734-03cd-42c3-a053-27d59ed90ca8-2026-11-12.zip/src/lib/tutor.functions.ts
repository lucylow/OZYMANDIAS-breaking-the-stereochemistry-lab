import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

const Input = z.object({
  question: z.string().trim().min(1).max(500),
  molecule: z
    .object({
      groups: z.array(z.object({ label: z.string().max(20), bond: z.enum(["plain", "wedge", "dash"]), position: z.string().max(40), priority: z.number().int().min(1).max(4) })).length(4),
      answer: z.enum(["R", "S"]),
    })
    .nullable(),
});

export const askTutor = createServerFn({ method: "POST" })
  .validator((d: unknown) => Input.parse(d))
  .handler(async ({ data }) => {
    const { explainStereo } = await import("./tutor.server");
    try {
      return { text: await explainStereo(data.question, data.molecule), error: null as string | null };
    } catch (e) {
      const status = (e as { statusCode?: number }).statusCode;
      console.error("tutor error", status, e);
      const error = status === 429 ? "The tutor is busy — try again in a moment." : status === 402 ? "AI credits have run out for this game." : "The tutor couldn't answer right now.";
      return { text: "", error };
    }
  });
