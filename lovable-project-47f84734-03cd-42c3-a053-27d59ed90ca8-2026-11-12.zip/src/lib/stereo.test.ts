import { describe, it, expect } from "vitest";
import { configuration, GROUPS, makePuzzle, SLOTS } from "./stereo";

describe("R/S rule", () => {
  it("1 top, 2 lower-right, 3 lower-left with 4 away is clockwise = R", () => {
    expect(configuration([[0, 1, 0], [0.87, -0.5, 0], [-0.87, -0.5, 0], [0, 0, -1]], [1, 2, 3, 4])).toBe("R");
  });
  it("same arrangement with 4 toward the viewer reverses to S", () => {
    expect(configuration([[0, 1, 0], [0.87, -0.5, 0], [-0.87, -0.5, 0], [0, 0, 1]], [1, 2, 3, 4])).toBe("S");
  });
  it("swapping any two groups inverts the configuration", () => {
    const v = SLOTS.map((s) => s.v);
    expect(configuration(v, [1, 2, 3, 4])).not.toBe(configuration(v, [2, 1, 3, 4]));
  });
});

describe("CIP ranking", () => {
  const r = (l: string) => GROUPS.find((g) => g.label === l)!.rank;
  it("Br > OH > CH3 > H", () => expect(r("Br") < r("OH") && r("OH") < r("CH₃") && r("CH₃") < r("H")).toBe(true));
  it("CHO outranks CH2OH, which outranks ethyl", () => expect(r("CHO") < r("CH₂OH") && r("CH₂OH") < r("CH₂CH₃")).toBe(true));
  it("early levels put H on the dash", () => {
    for (let i = 0; i < 20; i++) expect(makePuzzle(1).groups[3]!.label).toBe("H");
  });
});

import { READ_FROM_DRAWING } from "./stereo";
import { MODELS, angleDeg } from "./geometry";
import { configString, shells, bySymbol, ELEMENTS } from "./elements";

describe("drawing matches 3D", () => {
  it("wedge-dash drawing gives the same R/S as the true tetrahedron for all 24 orderings", () => {
    const perms: number[][] = [];
    const go = (a: number[], r: number[]) => (r.length ? r.forEach((x, i) => go([...a, x], r.filter((_, j) => j !== i))) : perms.push(a));
    go([], [1, 2, 3, 4]);
    for (const p of perms) expect(configuration(READ_FROM_DRAWING, p)).toBe(configuration(SLOTS.map((s) => s.v), p));
  });
});

describe("geometry and elements", () => {
  const m = (id: string) => MODELS.find((x) => x.id === id)!;
  it("methane is 109.5°", () => expect(angleDeg(m("ch4").atoms[1]!.p, [0, 0, 0], m("ch4").atoms[2]!.p)).toBeCloseTo(109.47, 1));
  it("ammonia is 107°", () => expect(angleDeg(m("nh3").atoms[1]!.p, [0, 0, 0], m("nh3").atoms[2]!.p)).toBeCloseTo(107, 1));
  it("water is 104.5°", () => expect(angleDeg(m("h2o").atoms[1]!.p, [0, 0, 0], m("h2o").atoms[2]!.p)).toBeCloseTo(104.5, 1));
  it("BF3 is 120°", () => expect(angleDeg(m("bf3").atoms[1]!.p, [0, 0, 0], m("bf3").atoms[2]!.p)).toBeCloseTo(120, 1));
  it("has 118 elements, O is 1s² 2s² 2p⁴", () => { expect(ELEMENTS.length).toBe(118); expect(configString(8)).toBe("1s² 2s² 2p⁴"); });
  it("Cr and Cu exceptions", () => { expect(configString(24)).toContain("3d⁵ 4s¹"); expect(configString(29)).toContain("3d¹⁰ 4s¹"); });
  it("Br shells 2,8,18,7", () => expect(shells(bySymbol("Br").z)).toEqual([2, 8, 18, 7]));
});
