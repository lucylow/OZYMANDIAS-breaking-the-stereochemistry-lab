// Pure question generators for arcade mini-games.
import { ELEMENTS } from "./elements";
import { MODELS } from "./geometry";

const shuffle = <T,>(a: T[], r = Math.random) => { const b = [...a]; for (let i = b.length - 1; i > 0; i--) { const j = Math.floor(r() * (i + 1)); [b[i], b[j]] = [b[j]!, b[i]!]; } return b; };

export type Q = { prompt: string; options: string[]; answer: string; explain: string };
const POOL = ELEMENTS.slice(0, 36);
export function elementQuestion(r = Math.random): Q {
  const e = POOL[Math.floor(r() * POOL.length)]!;
  const kind = Math.floor(r() * 3);
  const others = shuffle(POOL.filter((x) => x.z !== e.z), r).slice(0, 3);
  const field = (x: typeof e) => kind === 0 ? x.symbol : kind === 1 ? x.name : x.symbol;
  const prompt = kind === 0 ? `Symbol for ${e.name}?` : kind === 1 ? `Which element is ${e.symbol}?` : `Atomic number ${e.z} is…`;
  return { prompt, answer: field(e), options: shuffle([e, ...others], r).map(field), explain: `${e.name} (${e.symbol}) has atomic number ${e.z}: ${e.z} protons in its nucleus.` };
}

export const SHAPES = [...new Set(MODELS.map((m) => m.shape))];
export function shapeQuestion(r = Math.random) {
  const m = MODELS[Math.floor(r() * MODELS.length)]!;
  const opts = shuffle([m.shape, ...shuffle(SHAPES.filter((s) => s !== m.shape), r).slice(0, 3)], r);
  return { model: m, options: opts, answer: m.shape, explain: `${m.formula}: ${m.shape}, ${m.angle}. ${m.lonePairs ? `${m.lonePairs} lone pair${m.lonePairs > 1 ? "s" : ""} on the centre. ` : ""}${m.note}` };
}
