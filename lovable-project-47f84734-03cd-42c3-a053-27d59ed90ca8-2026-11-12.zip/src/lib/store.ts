// Tiny localStorage-backed stores for progress and settings.
import { useSyncExternalStore } from "react";
import { apply, EMPTY, type GameEvent, type Progress } from "./progress";

function createStore<T>(key: string, init: T) {
  let value = init, loaded = false;
  const subs = new Set<() => void>();
  const load = () => { if (!loaded && typeof window !== "undefined") { loaded = true; try { const s = localStorage.getItem(key); if (s) value = { ...init, ...JSON.parse(s) }; } catch { /* ignore */ } } };
  return {
    get: () => { load(); return value; },
    set: (v: T) => { value = v; localStorage.setItem(key, JSON.stringify(v)); subs.forEach((f) => f()); },
    use: () => useSyncExternalStore((f) => { subs.add(f); return () => subs.delete(f); }, () => { load(); return value; }, () => init),
  };
}

export type Settings = { volume: number; muted: boolean; reduceMotion: boolean };
export const settings = createStore<Settings>("dhe-settings", { volume: 0.6, muted: false, reduceMotion: false });
export const progress = createStore<Progress>("dhe-progress", EMPTY);

export type Reward = ReturnType<typeof apply>;
const listeners = new Set<(r: Reward) => void>();
export const onReward = (f: (r: Reward) => void) => { listeners.add(f); return () => { listeners.delete(f); }; };
export function record(e: GameEvent) {
  const r = apply(progress.get(), e);
  progress.set(r.progress);
  listeners.forEach((f) => f(r));
  return r;
}
