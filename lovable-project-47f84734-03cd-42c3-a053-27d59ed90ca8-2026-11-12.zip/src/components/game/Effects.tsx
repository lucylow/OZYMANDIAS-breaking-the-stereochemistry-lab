// Confetti and cartoon smoke — pure CSS, mounted only while active.
const CONF = Array.from({ length: 28 }, (_, i) => i);
export function Confetti() {
  return (
    <div className="pointer-events-none fixed inset-0 z-30 overflow-hidden" aria-hidden>
      {CONF.map((i) => <span key={i} className={`confetti c${i % 4}`} style={{ left: `${(i * 37) % 100}%`, animationDelay: `${(i % 7) * 0.08}s`, transform: `rotate(${i * 25}deg)` }} />)}
    </div>
  );
}
export function CartoonFailureSequence({ children }: { children?: React.ReactNode }) {
  return (
    <div className="pointer-events-none absolute inset-0 z-20 flex items-center justify-center" aria-hidden>
      <div className="w-64 h-64 rounded-full bg-accent animate-boom" />
      {[0, 1, 2, 3, 4].map((i) => <span key={i} className="smoke-puff" style={{ left: `${15 + i * 16}%`, animationDelay: `${0.2 + i * 0.1}s` }} />)}
      {[0, 1, 2].map((i) => <span key={i} className="flying-paper" style={{ animationDelay: `${0.1 + i * 0.15}s`, left: `${30 + i * 20}%` }} />)}
      {children}
    </div>
  );
}
