import { useState } from "react";
import { play } from "@/lib/sfx";

const MOLS = ["H₂O", "CH₄", "NH₃", "CO₂", "C*", "O₂", "BF₃", "HCN"];
// Decorative, low-cost CSS lab scene. Test tubes and the emergency button are interactive.
export function AnimatedLabBackground({ danger = false, success = false }: { danger?: boolean; success?: boolean }) {
  const [bubbling, setBubbling] = useState<number | null>(null);
  const [contain, setContain] = useState(false);
  const tube = (i: number) => { setBubbling(i); play("bubble"); setTimeout(() => setBubbling(null), 1200); };
  const emergency = () => { if (contain) return; setContain(true); play("alarm"); setTimeout(() => setContain(false), 2600); };
  return (
    <>
      <div className="pointer-events-none fixed inset-0 -z-10 overflow-hidden" aria-hidden>
        <div className={`absolute inset-0 transition-colors duration-700 ${danger ? "lab-light-danger" : success ? "lab-light-success" : "lab-light"}`} />
        <div className="absolute inset-0 lab-grid" />
        {MOLS.map((m, i) => (
          <span key={m} className="floating-mol" style={{ left: `${(i * 13 + 5) % 92}%`, animationDelay: `${-i * 3.1}s`, animationDuration: `${18 + (i % 4) * 5}s` }}>{m}</span>
        ))}
        <div className={`warning-light left-3 ${danger || contain ? "animate-blink" : "opacity-30"}`} />
        <div className={`warning-light right-3 ${danger || contain ? "animate-blink" : "opacity-30"}`} style={{ animationDelay: ".4s" }} />
      </div>
      <div className="fixed bottom-2 left-2 z-10 flex items-end gap-2">
        {[0, 1, 2].map((i) => (
          <button key={i} onClick={() => tube(i)} aria-label={`Test tube ${i + 1}: make it bubble`} className={`test-tube tube-${i}`}>
            <span className="tube-liquid" />
            {bubbling === i && [0, 1, 2, 3].map((b) => <span key={b} className="bubble" style={{ left: `${20 + b * 15}%`, animationDelay: `${b * 0.15}s` }} />)}
          </button>
        ))}
      </div>
      <button onClick={emergency} aria-label="Emergency containment button" className="emergency-btn fixed bottom-3 right-3 z-10">STOP</button>
      {contain && (
        <div className="pointer-events-none fixed inset-0 z-40 flex items-center justify-center" role="status">
          <div className="shutter shutter-top" /><div className="shutter shutter-bottom" />
          <p className="relative font-display text-2xl text-accent animate-pop">CONTAINMENT ENGAGED</p>
        </div>
      )}
    </>
  );
}
