export type Mood = "idle" | "talk" | "happy" | "shocked" | "think";
// Professor Proton: a cartoon proton (+) scientist drawn in SVG; mood drives face + motion.
export function ProfessorProton({ mood = "idle", line, size = 88 }: { mood?: Mood; line?: string; size?: number }) {
  const anim = mood === "happy" ? "animate-hop" : mood === "shocked" ? "animate-wobble" : "animate-bob";
  return (
    <div className="flex items-end gap-2" aria-live="polite">
      <svg viewBox="0 0 100 110" width={size} height={size * 1.1} className={`shrink-0 ${anim}`} aria-label={`Professor Proton looks ${mood}`} role="img">
        {/* lab coat */}
        <path d="M22 108 L30 70 H70 L78 108 Z" className="fill-foreground" />
        <path d="M50 70 V108" className="stroke-muted" strokeWidth={2} />
        {/* proton body */}
        <circle cx={50} cy={44} r={30} className="fill-destructive" />
        <text x={50} y={30} textAnchor="middle" className="fill-destructive-foreground font-bold" fontSize={14}>+</text>
        {/* wild hair */}
        <path d="M24 30 Q18 14 30 18 Q34 6 44 14 Q52 2 58 14 Q70 6 72 18 Q84 16 76 32" className="fill-none stroke-foreground" strokeWidth={4} strokeLinecap="round" />
        {/* goggles */}
        <circle cx={39} cy={44} r={9} className="fill-card stroke-accent" strokeWidth={3} />
        <circle cx={61} cy={44} r={9} className="fill-card stroke-accent" strokeWidth={3} />
        <line x1={48} y1={44} x2={52} y2={44} className="stroke-accent" strokeWidth={3} />
        {mood === "shocked" ? (<><circle cx={39} cy={44} r={5} className="fill-foreground" /><circle cx={61} cy={44} r={5} className="fill-foreground" /></>)
          : mood === "happy" ? (<><path d="M34 46 Q39 40 44 46" className="fill-none stroke-foreground" strokeWidth={3} /><path d="M56 46 Q61 40 66 46" className="fill-none stroke-foreground" strokeWidth={3} /></>)
          : (<><circle cx={mood === "think" ? 42 : 39} cy={mood === "think" ? 41 : 44} r={3} className="fill-foreground" /><circle cx={mood === "think" ? 64 : 61} cy={mood === "think" ? 41 : 44} r={3} className="fill-foreground" /></>)}
        {/* mouth */}
        {mood === "shocked" ? <ellipse cx={50} cy={62} rx={6} ry={7} className="fill-foreground" />
          : mood === "happy" ? <path d="M38 58 Q50 70 62 58 Z" className="fill-foreground" />
          : mood === "think" ? <path d="M42 62 H58" className="stroke-foreground" strokeWidth={3} strokeLinecap="round" />
          : <path d="M42 60 Q50 66 58 60" className={`fill-none stroke-foreground ${mood === "talk" ? "animate-talk" : ""}`} strokeWidth={3} strokeLinecap="round" />}
        {mood === "think" && <circle cx={88} cy={18} r={6} className="fill-card stroke-border" />}
      </svg>
      {line && <p className="speech-bubble animate-pop text-sm max-w-[16rem]">{line}</p>}
    </div>
  );
}
