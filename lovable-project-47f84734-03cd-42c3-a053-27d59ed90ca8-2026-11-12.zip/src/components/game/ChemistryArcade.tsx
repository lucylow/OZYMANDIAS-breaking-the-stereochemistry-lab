import { useEffect, useState } from "react";
import { elementQuestion, shapeQuestion, type Q } from "@/lib/arcade";
import { cpk } from "@/lib/elements";
import type { Model } from "@/lib/geometry";
import { record } from "@/lib/store";
import { play } from "@/lib/sfx";
import { ProfessorProton, type Mood } from "./ProfessorProton";
import { Confetti } from "./Effects";

type Game = "sprint" | "shape";
const INFO: Record<Game, { title: string; icon: string; how: string; seconds: number }> = {
  sprint: { title: "Periodic Table Sprint", icon: "⚡", how: "Match names, symbols and atomic numbers as fast as you can.", seconds: 45 },
  shape: { title: "Molecular Shape Match", icon: "🔺", how: "Name the VSEPR geometry of each molecule. Lone pairs count!", seconds: 60 },
};

function ModelSketch({ m }: { m: Model }) {
  const S = 42, pts = m.atoms.map((a) => [a.p[0] * S, -a.p[1] * S, a.p[2]] as const);
  return (
    <svg viewBox="-110 -90 220 180" className="w-full max-w-[16rem] animate-spin-slow-y" role="img" aria-label={`${m.name} structure`}>
      {m.bonds.map((b, i) => { const A = pts[b.a]!, B = pts[b.b]!; return <line key={i} x1={A[0]} y1={A[1]} x2={B[0]} y2={B[1]} className="stroke-foreground" strokeWidth={b.order * 3} strokeDasharray={b.style === "dash" ? "3 4" : undefined} />; })}
      {pts.map((p, i) => ({ p, i })).sort((a, b) => a.p[2] - b.p[2]).map(({ p, i }) => (
        <g key={i}><circle cx={p[0]} cy={p[1]} r={m.atoms[i]!.el === "H" ? 11 : 17} fill={cpk(m.atoms[i]!.el)} className="stroke-background" strokeWidth={2} />
          <text x={p[0]} y={p[1] + 4} textAnchor="middle" fontSize={11} className="fill-background font-bold">{m.atoms[i]!.el}</text></g>))}
    </svg>
  );
}

function MiniGame({ game, onExit }: { game: Game; onExit: () => void }) {
  const info = INFO[game];
  const [count, setCount] = useState(3);
  const [time, setTime] = useState(info.seconds);
  const [score, setScore] = useState(0);
  const [wrong, setWrong] = useState(0);
  const [q, setQ] = useState<(Q & { model?: Model }) | null>(null);
  const [feedback, setFeedback] = useState<{ ok: boolean; text: string; pick: string } | null>(null);
  const next = () => { setFeedback(null); setQ(game === "sprint" ? elementQuestion() : shapeQuestion() as Q & { model: Model; prompt: string }); };
  useEffect(() => { next(); }, []);
  useEffect(() => {
    if (count > 0) { const t = setTimeout(() => { setCount((c) => c - 1); play("click"); }, 700); return () => clearTimeout(t); }
    if (time <= 0) return;
    const t = setTimeout(() => setTime((x) => x - 1), 1000); return () => clearTimeout(t);
  }, [count, time]);
  const done = count === 0 && time <= 0;
  const answer = (o: string) => {
    if (!q || feedback || done) return;
    const ok = o === q.answer;
    setFeedback({ ok, pick: o, text: ok ? q.explain : `Not quite — it's ${q.answer}. ${q.explain}` });
    if (ok) { setScore((s) => s + 1); play("correct"); record({ type: game === "sprint" ? "element" : "shape" }); } else { setWrong((w) => w + 1); play("wrong"); }
    setTimeout(next, ok ? 1100 : 2600);
  };
  const mood: Mood = !feedback ? "talk" : feedback.ok ? "happy" : "think";
  return (
    <div className="w-full max-w-md flex flex-col items-center gap-4">
      <div className="w-full flex justify-between items-center font-display text-sm"><button onClick={onExit} className="btn-icon" aria-label="Back to arcade">←</button><span>{info.title}</span><span className="text-primary">{score}</span></div>
      {count > 0 ? <p key={count} className="font-display text-8xl text-accent animate-countdown my-16">{count}</p>
        : done ? (
          <div className="game-card text-center space-y-3 animate-pop w-full">
            {score >= 5 && <Confetti />}
            <ProfessorProton mood={score > wrong ? "happy" : "think"} line={score > wrong ? "Superb! Your chemistry instincts are sharpening." : "Every mistake is data. Review the explanations and try again!"} />
            <p className="font-display text-2xl">{score} correct · {wrong} missed</p>
            <p className="text-sm text-muted-foreground">{game === "sprint" ? "Atomic number = proton count, and it fixes the element's identity." : "VSEPR: electron domains (bonds + lone pairs) spread out to minimise repulsion; lone pairs squeeze bond angles."}</p>
            <div className="flex gap-2 justify-center"><button onClick={() => { setScore(0); setWrong(0); setTime(info.seconds); setCount(3); next(); }} className="btn-game bg-primary text-primary-foreground">Replay</button><button onClick={onExit} className="btn-game bg-secondary text-secondary-foreground">Arcade</button></div>
          </div>
        ) : q && (
          <>
            <div className="w-full h-2 rounded-full bg-muted overflow-hidden" role="progressbar" aria-label="Time left" aria-valuenow={time} aria-valuemin={0} aria-valuemax={info.seconds}><div className="h-full bg-accent transition-all duration-1000" style={{ width: `${(time / info.seconds) * 100}%` }} /></div>
            <ProfessorProton mood={mood} size={60} />
            <div key={q.prompt + (q.model?.id ?? "")} className={`game-card w-full flex flex-col items-center gap-2 animate-pop ${feedback && !feedback.ok ? "animate-shake-soft" : ""}`}>
              {q.model && <><ModelSketch m={q.model} /><p className="font-display text-xl">{q.model.formula}</p></>}
              <p className="font-semibold text-lg text-center">{q.model ? "What is its shape?" : q.prompt}</p>
            </div>
            <div className="grid grid-cols-2 gap-2 w-full">
              {q.options.map((o) => {
                const st = feedback && (o === q.answer ? "answer-correct" : o === feedback.pick ? "answer-wrong" : "opacity-50");
                return <button key={o} onClick={() => answer(o)} disabled={!!feedback} className={`btn-answer ${st || ""}`}>{o}</button>;
              })}
            </div>
            {feedback && <p className={`text-sm text-center rounded-md px-3 py-2 animate-pop ${feedback.ok ? "bg-success-soft" : "bg-card border"}`} role="status">{feedback.text}</p>}
          </>
        )}
    </div>
  );
}

export function ChemistryArcade() {
  const [game, setGame] = useState<Game | null>(null);
  if (game) return <MiniGame key={game} game={game} onExit={() => setGame(null)} />;
  return (
    <div className="grid gap-3 w-full max-w-md">
      {(Object.keys(INFO) as Game[]).map((g) => (
        <button key={g} onClick={() => { play("click"); setGame(g); }} className="game-card game-card-hover text-left flex gap-4 items-center">
          <span className="text-4xl animate-bob">{INFO[g].icon}</span>
          <span><span className="font-display block">{INFO[g].title}</span><span className="text-sm text-muted-foreground">{INFO[g].how}</span></span>
        </button>
      ))}
    </div>
  );
}
