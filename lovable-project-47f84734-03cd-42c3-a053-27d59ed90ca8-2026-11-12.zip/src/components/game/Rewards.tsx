import { useEffect, useState } from "react";
import { ACHIEVEMENTS, rankProgress, type AchievementId } from "@/lib/progress";
import { onReward, progress } from "@/lib/store";
import { play } from "@/lib/sfx";
import { Confetti } from "./Effects";

export function XPProgressBar({ compact = false }: { compact?: boolean }) {
  const p = progress.use();
  const r = rankProgress(p.xp);
  return (
    <div className={compact ? "w-full" : "w-full max-w-sm"}>
      <div className="flex justify-between text-xs font-semibold"><span className="text-primary">{r.title}</span><span className="text-muted-foreground">{p.xp} XP{r.span ? ` · ${r.span - r.into} to next` : " · max rank"}</span></div>
      <div className="mt-1 h-2.5 rounded-full bg-muted overflow-hidden" role="progressbar" aria-label="Experience" aria-valuenow={Math.round(r.pct * 100)} aria-valuemin={0} aria-valuemax={100}>
        <div className="h-full bg-gradient-xp transition-all duration-700" style={{ width: `${r.pct * 100}%` }} />
      </div>
    </div>
  );
}

// Listens for rewards anywhere in the app: XP toasts, achievement popups, level-up celebration.
export function RewardLayer() {
  const [toasts, setToasts] = useState<{ id: number; text: string; icon: string }[]>([]);
  const [levelUp, setLevelUp] = useState<string | null>(null);
  useEffect(() => onReward((r) => {
    const add = (text: string, icon: string) => { const id = Math.random(); setToasts((t) => [...t, { id, text, icon }]); setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), 2800); };
    if (r.gained) add(`+${r.gained} XP`, "⚡");
    r.unlocked.forEach((a: AchievementId) => add(`Achievement: ${ACHIEVEMENTS[a].name}`, ACHIEVEMENTS[a].icon));
    if (r.leveledUp) { setLevelUp(rankProgress(r.progress.xp).title); play("levelup"); }
  }), []);
  return (
    <>
      <div className="fixed top-14 right-3 z-50 flex flex-col gap-2 items-end" role="status">
        {toasts.map((t) => <div key={t.id} className="achievement-toast animate-slide-in"><span className="text-lg">{t.icon}</span>{t.text}</div>)}
      </div>
      {levelUp && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-overlay p-6" role="dialog" aria-label="Level up">
          <Confetti />
          <div className="relative bg-card border-2 border-primary rounded-2xl p-6 text-center glow animate-pop max-w-xs">
            <p className="font-display text-3xl text-primary">RANK UP!</p>
            <p className="mt-2 text-muted-foreground">You are now a</p>
            <p className="font-display text-xl text-accent">{levelUp}</p>
            <div className="mt-4"><XPProgressBar compact /></div>
            <button onClick={() => setLevelUp(null)} className="btn-game mt-5 bg-primary text-primary-foreground">Keep going</button>
          </div>
        </div>
      )}
    </>
  );
}

export function RewardCollection() {
  const p = progress.use();
  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
      {(Object.keys(ACHIEVEMENTS) as AchievementId[]).map((id) => {
        const a = ACHIEVEMENTS[id], got = p.achievements.includes(id);
        return (
          <div key={id} className={`game-card text-center ${got ? "border-primary glow" : "opacity-50"}`}>
            <div className={`text-3xl ${got ? "animate-bob" : "grayscale"}`}>{got ? a.icon : "🔒"}</div>
            <p className="font-semibold text-sm mt-1">{a.name}</p>
            <p className="text-xs text-muted-foreground">{a.desc}</p>
          </div>
        );
      })}
    </div>
  );
}
