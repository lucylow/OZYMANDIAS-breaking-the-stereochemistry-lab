import { useEffect, useState } from "react";
import { settings } from "@/lib/store";
import { play } from "@/lib/sfx";

// Applies reduced motion globally and offers sound/motion controls.
export function useApplyMotion() {
  const s = settings.use();
  useEffect(() => { document.documentElement.classList.toggle("reduce-motion", s.reduceMotion); }, [s.reduceMotion]);
}

export function SettingsPanel() {
  const s = settings.use();
  const [open, setOpen] = useState(false);
  return (
    <div className="relative">
      <button onClick={() => setOpen((o) => !o)} aria-expanded={open} aria-label="Sound and motion settings" className="btn-icon">{s.muted ? "🔇" : "🔊"}</button>
      {open && (
        <div className="absolute right-0 top-11 z-50 w-60 game-card animate-pop space-y-3 text-sm text-left">
          <label className="flex items-center justify-between gap-2">Mute all sound
            <input type="checkbox" checked={s.muted} onChange={(e) => settings.set({ ...s, muted: e.target.checked })} className="accent-primary size-4" /></label>
          <label className="block">Volume
            <input type="range" min={0} max={1} step={0.1} value={s.volume} disabled={s.muted} onChange={(e) => settings.set({ ...s, volume: Number(e.target.value) })} onPointerUp={() => play("click")} className="w-full accent-primary" aria-label="Volume" /></label>
          <label className="flex items-center justify-between gap-2">Reduce motion
            <input type="checkbox" checked={s.reduceMotion} onChange={(e) => settings.set({ ...s, reduceMotion: e.target.checked })} className="accent-primary size-4" /></label>
        </div>
      )}
    </div>
  );
}
