import { Canvas } from "@react-three/fiber";
import { OrbitControls, Html, Line } from "@react-three/drei";
import { useRef } from "react";
import type { OrbitControls as OC } from "three-stdlib";
import { SLOTS, type Puzzle } from "@/lib/stereo";

const PRIO_COLOR = ["#f5b02e", "#e8663d", "#4fb0c6", "#8a8f98"];

export default function Molecule3D({ p, showRanks }: { p: Puzzle; showRanks: boolean }) {
  const controls = useRef<OC>(null);
  return (
    <div className="relative w-full max-w-sm aspect-square rounded-lg border bg-card" data-scene-ready>
      <Canvas camera={{ position: [0, 0, 4.2], fov: 45 }}>
        <ambientLight intensity={0.6} />
        <directionalLight position={[3, 4, 5]} intensity={1.4} />
        <mesh><sphereGeometry args={[0.32, 32, 32]} /><meshStandardMaterial color="#3a3f47" roughness={0.4} /></mesh>
        {SLOTS.map((s, i) => {
          const [x, y, z] = s.v.map((c) => c * 1.5) as [number, number, number];
          const pr = p.priorities[i]!;
          return (
            <group key={i}>
              <Line points={[[0, 0, 0], [x, y, z]]} color="#c9ccd1" lineWidth={4} />
              <mesh position={[x, y, z]}>
                <sphereGeometry args={[0.28, 32, 32]} />
                <meshStandardMaterial color={showRanks ? PRIO_COLOR[pr - 1]! : "#d9dce1"} roughness={0.35} />
              </mesh>
              <Html position={[x, y + 0.42, z]} center className="pointer-events-none select-none">
                <span className="rounded bg-background/80 px-1.5 text-xs font-bold text-foreground whitespace-nowrap">
                  {p.groups[i]!.label}{showRanks ? ` · ${pr}` : ""}
                </span>
              </Html>
            </group>
          );
        })}
        <OrbitControls ref={controls} enablePan={false} minDistance={2.5} maxDistance={8} />
      </Canvas>
      <button onClick={() => controls.current?.reset()} className="absolute bottom-2 right-2 text-xs bg-secondary text-secondary-foreground px-2 py-1 rounded">Reset view</button>
      <p className="absolute top-2 left-2 text-[10px] text-muted-foreground">Drag to rotate · scroll/pinch to zoom</p>
    </div>
  );
}
