import { useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { askTutor } from "@/lib/tutor.functions";
import { SLOTS, type Puzzle } from "@/lib/stereo";

const CLOCK = ["10 o'clock (upper left)", "8 o'clock (lower left)", "4 o'clock (lower right)", "2 o'clock (upper right)"];

export function AskTutor({ puzzle }: { puzzle: Puzzle | null }) {
  const ask = useServerFn(askTutor);
  const [open, setOpen] = useState(false);
  const [q, setQ] = useState("");
  const [answer, setAnswer] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!q.trim() || loading) return;
    setLoading(true); setError(""); setAnswer("");
    const molecule = puzzle
      ? { groups: puzzle.groups.map((g, i) => ({ label: g.label, bond: SLOTS[i]!.bond, position: CLOCK[i]!, priority: puzzle.priorities[i]! })), answer: puzzle.answer }
      : null;
    try {
      const r = await ask({ data: { question: q, molecule } });
      r.error ? setError(r.error) : setAnswer(r.text);
    } catch { setError("The tutor couldn't answer right now."); }
    finally { setLoading(false); }
  };

  if (!open) return <button onClick={() => setOpen(true)} className="text-sm underline text-accent">🧪 Ask the lab tutor</button>;
  return (
    <form onSubmit={submit} className="w-full max-w-sm bg-card border rounded-lg p-3 space-y-2" aria-label="Ask the lab tutor">
      <label htmlFor="tutor-q" className="text-sm font-semibold">Describe your stereochemistry question</label>
      <textarea id="tutor-q" value={q} onChange={(e) => setQ(e.target.value)} maxLength={500} rows={3}
        placeholder="Why is this molecule R or S?" className="w-full rounded-md bg-background border p-2 text-sm" />
      <div className="flex gap-2">
        <button type="submit" disabled={loading || !q.trim()} className="font-display text-sm bg-primary text-primary-foreground px-4 py-2 rounded-md disabled:opacity-50">{loading ? "Thinking…" : "Explain"}</button>
        <button type="button" onClick={() => setOpen(false)} className="text-sm text-muted-foreground">Close</button>
      </div>
      {error && <p role="alert" className="text-sm text-destructive">{error}</p>}
      {answer && <p className="text-sm whitespace-pre-wrap" data-testid="tutor-answer">{answer}</p>}
      <p className="text-xs text-muted-foreground">AI-powered tutor. Tip: it reveals the answer, so ask after you call R or S.</p>
    </form>
  );
}
