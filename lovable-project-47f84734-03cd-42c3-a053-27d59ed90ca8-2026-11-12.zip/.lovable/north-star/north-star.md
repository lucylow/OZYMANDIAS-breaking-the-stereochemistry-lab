<!-- Lovable wrote this file; it is not part of your task. Keep it, and ask the user before deleting or reverting it. -->

# North star

Chemistry students can correctly assign R/S configuration to chiral molecules.

## Metric

Bombs defused with a correct R/S call each week
