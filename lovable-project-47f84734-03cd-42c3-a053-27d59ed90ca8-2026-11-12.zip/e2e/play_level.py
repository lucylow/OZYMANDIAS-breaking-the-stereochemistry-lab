"""End-to-end: play level 1 in a real browser and check the molecule interaction.
Run: python3 e2e/play_level.py  (dev server on http://localhost:8080)"""
import asyncio, re, sys
from playwright.async_api import async_playwright, expect

URL = "http://localhost:8080/"
# CIP order, highest priority first (mirrors src/lib/stereo.ts GROUPS).
ORDER = ["I", "Br", "Cl", "SH", "F", "OH", "NH₂", "COOH", "CHO", "CH₂OH", "CH=CH₂", "CH₂CH₃", "CH₃", "H"]
# 2D drawing positions of slots 0-3 (SVG, y down) — mirrors SLOTS.draw.
DRAW = [(-0.58, -0.82), (-0.58, 0.82), (0.8, 0.5), (0.8, -0.5)]

def label_of(aria: str) -> str:
    return aria.split(",")[0].strip()

async def main():
    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=True)
        page = await (await browser.new_context(viewport={"width": 1280, "height": 1800})).new_page()
        errors = []
        page.on("pageerror", lambda e: errors.append(str(e)))
        await page.goto(URL, wait_until="networkidle")
        await page.get_by_role("button", name="Start defusing").click()
        await expect(page.get_by_text("LVL 1")).to_be_visible()

        mol = page.get_by_role("group", name=re.compile("Molecule"))
        groups = mol.get_by_role("button")
        await expect(groups).to_have_count(4)
        labels = [label_of(await groups.nth(i).get_attribute("aria-label")) for i in range(4)]
        assert labels[3] == "H", f"level 1 should put H on the dash, got {labels}"
        prio = sorted(range(4), key=lambda i: ORDER.index(labels[i]))  # slot indices, priority 1..4

        # Wrong pick: shows the misconception and costs 3 seconds.
        fuse = page.get_by_role("progressbar", name="Fuse")
        before = int(await fuse.get_attribute("aria-valuenow"))
        await groups.nth(prio[2]).click()
        await expect(page.get_by_role("status")).to_contain_text("Not priority 1")
        after = int(await fuse.get_attribute("aria-valuenow"))
        assert after <= before - 3, f"wrong pick should cost 3 s ({before} -> {after})"

        # Correct ranking: each pick gets a rank badge; priority 4 auto-placed.
        for n, slot in enumerate(prio[:3], start=1):
            await groups.nth(slot).click()
            await expect(groups.nth(slot)).to_have_attribute("aria-label", re.compile(f"ranked {n}"))
        await expect(groups.nth(prio[3])).to_have_attribute("aria-label", re.compile("ranked 4"))
        await expect(page.get_by_text("Is this R or S?")).to_be_visible()

        # H points away, so 1→2→3 clockwise on screen (y down) = R.
        (x1, y1), (x2, y2), (x3, y3) = (DRAW[s] for s in prio[:3])
        cross = (x2 - x1) * (y3 - y2) - (y2 - y1) * (x3 - x2)
        answer = "R" if cross > 0 else "S"
        await page.get_by_role("button", name=answer, exact=True).click()
        await expect(page.get_by_text("Defused!")).to_be_visible()
        await expect(page.get_by_role("button", name="Next bomb →")).to_be_visible()
        assert not errors, f"page errors: {errors}"
        print(f"PASS: {labels} -> {answer}")
        await browser.close()

if __name__ == "__main__":
    for run in range(5):  # puzzles are random; play several
        asyncio.run(main())
    sys.exit(0)
